char number = 5;
char symbol_code = 'x';
char null_terminator = '\0';
