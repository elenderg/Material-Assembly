int first( int array[10], size_t sz ) { ... }
