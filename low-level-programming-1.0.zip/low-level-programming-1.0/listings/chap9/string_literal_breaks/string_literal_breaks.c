char const* hello = "Hel" "lo"
"world!";
