typedef void(proc)(void);

...

proc* my_ptr = &some_proc;
