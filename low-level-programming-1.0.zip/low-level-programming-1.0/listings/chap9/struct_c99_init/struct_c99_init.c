struct pair {
    char a;
    char b;
};

struct pair st = { .a = 'a',.b = 'b' };
