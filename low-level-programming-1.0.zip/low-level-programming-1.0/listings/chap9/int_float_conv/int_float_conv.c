int i;
float f;
double d = f + i;
