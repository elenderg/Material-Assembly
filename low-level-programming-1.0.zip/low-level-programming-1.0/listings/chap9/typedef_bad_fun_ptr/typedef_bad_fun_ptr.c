typedef  void(*proc)(void);
