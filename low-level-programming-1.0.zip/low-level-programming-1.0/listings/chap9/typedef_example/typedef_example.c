typedef unsigned short int mytype_t;
