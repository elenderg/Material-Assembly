int fun(int array[static 10] ) {...}
