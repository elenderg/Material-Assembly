#define mystr hello
#define res #mystr

puts( res );  /* will be replaced with `puts("hello")`
