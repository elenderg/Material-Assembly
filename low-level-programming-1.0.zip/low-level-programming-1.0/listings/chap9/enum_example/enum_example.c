enum light { 
    RED,
    RED_AND_YELLOW,
    YELLOW,
    GREEN,
    NOTHING
};

...
enum light l = nothing;
...
