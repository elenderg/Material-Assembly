struct pair { int a; int b; };

...
struct pair p = { 0 };
