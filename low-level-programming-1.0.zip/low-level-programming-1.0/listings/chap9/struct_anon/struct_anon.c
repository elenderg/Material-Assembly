struct { int a; char b; } d;
d.a = 0;
d.b = 'k';
