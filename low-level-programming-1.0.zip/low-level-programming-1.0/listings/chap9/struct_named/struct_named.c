struct pair { 
    int a; 
    int b; 
};

...

struct pair d;
d.a = 0;
d.b = 1;
