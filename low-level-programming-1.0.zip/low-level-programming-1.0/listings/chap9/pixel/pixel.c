union pixel {
    struct {
        char a,b,c;
    };
    char at[3];
};
