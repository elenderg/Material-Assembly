int myarray[1024];
int y = myarray[64];

int first = myarray[0];

myarray[10] = 42;
