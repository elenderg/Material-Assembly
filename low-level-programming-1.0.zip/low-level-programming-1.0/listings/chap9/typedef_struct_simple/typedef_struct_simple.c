typedef struct type type;
