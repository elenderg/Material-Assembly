#define SQUARE( x ) (x * x)

int x = SQUARE( 4+1 )
