4 = 2;
"abc"="bcd";
square(3) = 9;
