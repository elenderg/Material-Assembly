if (x == 0) 
    puts("X is zero");
else 
    puts("X is not zero"); 
