x = y = z;
(x = (y = z));
