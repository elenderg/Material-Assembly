int a[] = {1, 2, 3, 4}; /* an array of 4 elements */
int i = 0;             
for ( i = 0; i < 4; i++ ) {
    printf( "%d", a[i])
}
