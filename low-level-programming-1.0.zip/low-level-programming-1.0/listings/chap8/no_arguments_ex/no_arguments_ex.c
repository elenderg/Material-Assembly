int always_return_0( void ) { return 0; }
