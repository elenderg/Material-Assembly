void myproc ( int a, int b ) 
{
    printf("%d", a+b);
}
