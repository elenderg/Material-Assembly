int i;

/* as a `while` loop */
i = 0;
while ( i < 10 ) { 
    puts("Hello!");
    i = i + 1;
}

/* as a `for` loop */
for( i = 0; i < 10; i = i + 1 ) {
    puts("Hello!"); 
}
