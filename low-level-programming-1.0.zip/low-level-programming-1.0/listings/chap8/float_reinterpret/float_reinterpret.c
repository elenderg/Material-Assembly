#include <stdio.h>

int main(void) {
    printf("42.0 as an integer %d  \n", 42.0);
    return 0;
}
