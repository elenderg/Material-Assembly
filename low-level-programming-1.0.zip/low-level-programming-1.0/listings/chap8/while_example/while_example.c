int x = 10;
while ( x != 0 ) {
    puts("Hello");
    x = x - 1;
}
