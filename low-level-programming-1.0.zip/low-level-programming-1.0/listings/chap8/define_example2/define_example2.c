#define MACRO_SQUARE( x ) ((x) * (x))
