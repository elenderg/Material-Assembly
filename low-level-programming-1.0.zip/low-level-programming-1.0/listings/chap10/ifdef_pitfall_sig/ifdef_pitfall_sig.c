#ifdef SOMEFLAG
int foo() {
#else
    void foo() {
#endif
        /* ... */
    }
