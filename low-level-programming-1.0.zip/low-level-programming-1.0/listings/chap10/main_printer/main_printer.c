void print_one(void);
void print_two(void);
int main(void) {
    print_one();
    print_two();
    return 0;
}
