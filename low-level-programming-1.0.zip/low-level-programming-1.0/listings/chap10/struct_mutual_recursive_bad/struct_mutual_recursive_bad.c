struct a {
    struct b* foo;
};
struct b {
    struct a* bar;
};
