#ifdef SYMBOL
/*code*/
#endif
