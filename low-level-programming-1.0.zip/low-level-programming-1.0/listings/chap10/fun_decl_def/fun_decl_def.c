/* This is declaration */
void f( int x );

/* This is definition */
void f( int x )  {
    puts( "Hello!" );
}
