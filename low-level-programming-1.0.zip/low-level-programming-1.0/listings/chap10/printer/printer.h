void print_one( void );
void print_two( void );
