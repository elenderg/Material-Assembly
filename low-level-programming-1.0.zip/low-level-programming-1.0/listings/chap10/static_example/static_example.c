int global_int;
static int module_int;

static int module_function() { 
    static int static_local_var; 
    int local_var;
    return 0;
}
int main( int argc, char** argv ) { 
    return 0;
}
