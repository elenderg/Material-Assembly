#ifndef _FILE_H_
#define _FILE_H_

void a(void);

#endif
