#ifndef MYFLAG
/*code*/
#else
/*other code*/
#endif
