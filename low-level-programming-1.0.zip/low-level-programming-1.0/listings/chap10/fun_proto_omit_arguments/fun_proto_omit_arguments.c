int square( int x );
/* same as */
int square( int );

