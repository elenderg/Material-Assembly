#include "printer.h"

int main(void) {
    print_one();
    print_two(); 
    return 0;
}
