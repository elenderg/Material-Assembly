int square( int x ) { return x * x; }

...
int z = square(5);

