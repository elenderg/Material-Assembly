extern int z;
int square( int x ) { return x * x + z; }
