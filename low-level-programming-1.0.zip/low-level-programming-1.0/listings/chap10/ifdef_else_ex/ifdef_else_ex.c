#ifdef SYMBOL
/*code*/
#else
/*other code*/
#endif
