struct list { 
    int value;
    struct list* next;
};
