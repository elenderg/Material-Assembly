int square( int x );

...
int z = square(5);

...

int square( int x ) { return x * x; }
