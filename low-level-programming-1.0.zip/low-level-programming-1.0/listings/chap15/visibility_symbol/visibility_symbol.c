int 
__attribute__(( visibility( "default" ) )) 
func(int x) { return 42; }
