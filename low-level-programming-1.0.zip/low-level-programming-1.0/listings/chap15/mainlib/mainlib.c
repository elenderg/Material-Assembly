extern void libfun( int value );

int global = 100;

int main( void ) {
    libfun( 42 );
    return 0;
}
