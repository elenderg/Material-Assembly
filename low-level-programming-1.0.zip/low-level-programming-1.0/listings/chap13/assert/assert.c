#include <assert.h>
int main() {
    int x = 0;
    assert( x != 0 );
    return 0;
}
