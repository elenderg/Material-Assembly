struct pixel {
    unsigned char b, g, r; 
}
