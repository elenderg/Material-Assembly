struct mypair { 
    int x;
    int y;
    int _refcount;
};
