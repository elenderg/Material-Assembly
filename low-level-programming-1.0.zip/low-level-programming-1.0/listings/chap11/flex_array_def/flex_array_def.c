struct char_array {
    size_t length;
    char data[]; 
};
