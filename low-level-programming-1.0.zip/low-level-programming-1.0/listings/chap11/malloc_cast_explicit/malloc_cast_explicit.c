int* arr = (int*)malloc( sizeof(int) * 42 );
