char* str = "hello world abcdefghijkl"; 
/* the following line produces a runtime error */
str[15] = '\'';                              
