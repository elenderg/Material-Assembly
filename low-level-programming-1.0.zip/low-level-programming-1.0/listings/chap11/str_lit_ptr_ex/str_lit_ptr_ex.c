char will_be_o = "hello, world!"[4];  /* is 'o' */
char const* tail = "abcde"+3 ; /* is "de", skipping 3 symbols */
