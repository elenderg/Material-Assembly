void func(void) {
    char str[] = "something_local";
}
