int* (* (*fp) (int) ) [10];
