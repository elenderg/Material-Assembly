if( x ) { ... }
if( NULL != x ) { ... } 
if( 0 != x ) { ... }

if( x != NULL ) { ... } 
if( x != 0 ) { ... }
