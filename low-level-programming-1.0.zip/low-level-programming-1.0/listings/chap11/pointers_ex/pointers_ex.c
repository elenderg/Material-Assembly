int a = 4;
int* p_a = &a;
*p_a = 10; /* a = 10*/
