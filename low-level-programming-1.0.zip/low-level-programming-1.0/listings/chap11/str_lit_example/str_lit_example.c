char* str = "when the music is over, turn out the lights";
