char str[] = "something_global";
void f (void) { ... }
