int* a, *b, c;
