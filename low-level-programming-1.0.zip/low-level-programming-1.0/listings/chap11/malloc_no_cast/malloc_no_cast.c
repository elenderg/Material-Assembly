#include <malloc.h>
...
int* a =  malloc(200);

a[4] = 2;
