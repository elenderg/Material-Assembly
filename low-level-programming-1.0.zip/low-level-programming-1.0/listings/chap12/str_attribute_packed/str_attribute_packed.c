struct __attribute__(( packed )) mystr {
    uint8_t first;
    float delta;
    float position;
};
