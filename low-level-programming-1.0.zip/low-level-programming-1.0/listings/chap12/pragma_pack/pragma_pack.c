#pragma pack(push, 2)
struct mystr {
    short a;
    long b;
};
#pragma pack(pop)
