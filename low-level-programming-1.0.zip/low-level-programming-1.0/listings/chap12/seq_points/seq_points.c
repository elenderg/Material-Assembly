int i = 0;
i = i ++ * 10;
