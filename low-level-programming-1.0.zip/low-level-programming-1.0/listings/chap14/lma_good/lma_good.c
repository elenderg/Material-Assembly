volatile char* ptr;
for( ptr = start; ptr < start + size; ptr += pagesize )
*ptr;
