void f(int* x, int* add) {
    *x += *add;
    *x += *add;
}
